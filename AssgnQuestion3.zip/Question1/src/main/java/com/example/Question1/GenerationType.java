package com.example.Question1;

public enum GenerationType {
	IDENTITY

}
