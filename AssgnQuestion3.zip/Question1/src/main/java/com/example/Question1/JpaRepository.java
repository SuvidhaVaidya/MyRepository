package com.example.Question1;

public interface JpaRepository<T1, T2> {

}
