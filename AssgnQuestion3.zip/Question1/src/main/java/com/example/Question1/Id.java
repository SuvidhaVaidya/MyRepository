package com.example.Question1;

public @interface Id {

}
