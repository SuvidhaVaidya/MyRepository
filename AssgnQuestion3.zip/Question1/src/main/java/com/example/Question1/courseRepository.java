package com.example.Question1;

import java.util.List;
import java.util.Optional;

public interface courseRepository extends  JpaRepository<Course, Long> {

	List<Course> findAll();

	Optional<Course> findById(Long courseId);

	Course save(Course course);

	void deleteById(Long courseId);
}


