package com.example.Que1;

public class GenerationType {

	public static final String IDENTITY = null;

}
