package com.example.Que1;

public interface JpaRepository<T1, T2> {

}
