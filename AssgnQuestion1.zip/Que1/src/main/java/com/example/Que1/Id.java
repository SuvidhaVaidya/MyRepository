package com.example.Que1;

public @interface Id {

}
