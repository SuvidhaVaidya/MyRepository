package com.example.Que1;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {

	Student save(Student student);

	List<Student> findAll();

	boolean existsById(Long id);

	Object findById(Long id);

	void deleteById(Long id);
}
