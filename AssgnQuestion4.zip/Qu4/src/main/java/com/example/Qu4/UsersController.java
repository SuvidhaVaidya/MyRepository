package com.example.Qu4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UsersController {
    private final UsersService usersService;

    @Autowired
    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @PostMapping("/encrypt")
    public ResponseEntity<Users> createUserWithEncryptedPassword(@RequestParam String userName, @RequestParam String password) {
        Users user = usersService.createUser(userName, password, true);
        return ResponseEntity.ok(user);
    }

    @PostMapping("/decrypt/{encryptedPassword}")
    public ResponseEntity<String> decryptPassword(@PathVariable String encryptedPassword) {
        String decryptedPassword = usersService.decryptPassword(encryptedPassword);
        return ResponseEntity.ok(decryptedPassword);
    }

    @PostMapping("/validate")
    public ResponseEntity<String> validateUserPassword(@RequestParam String userName, @RequestParam String password) {
        boolean isValid = usersService.validateUserPassword(userName, password);
        if (isValid) {
            return ResponseEntity.ok("Valid user");
        }
        return ResponseEntity.badRequest().body("Invalid user");
    }
}
