package com.example.Qu4;

public interface UsersRepository extends JpaRepository<Users, Long> {
    Users findByUserName(String userName);

	Users save(Users user);

}