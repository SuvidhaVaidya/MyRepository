package com.example.Qu4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersService {
    private final UsersRepository usersRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    public UsersService(UsersRepository usersRepository, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.usersRepository = usersRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    public Users createUser(String userName, String password, boolean enabled) {
        String encryptedPassword = bCryptPasswordEncoder.encode(password);
        Users user = new Users(null, encryptedPassword, encryptedPassword, enabled);
        user.setUserName(userName);
        user.setPassword(encryptedPassword);
        user.setEnabled(enabled);
        return usersRepository.save(user);
    }

    public String decryptPassword(String encryptedPassword) {
        return bCryptPasswordEncoder.decode(encryptedPassword);
    }

    public boolean validateUserPassword(String userName, String providedPassword) {
        Users user = usersRepository.findByUserName(userName);
        if (user != null) {
            return bCryptPasswordEncoder.matches(providedPassword, user.getPassword());
        }
        return false;
    }
}
