package com.example.Qu4;

public class BCryptPasswordEncoder {

	public String decode(String encryptedPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean matches(String providedPassword, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	public String encode(String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
