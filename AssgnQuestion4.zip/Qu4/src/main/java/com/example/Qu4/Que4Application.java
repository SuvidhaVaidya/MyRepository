package com.example.Qu4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Que4Application {

	public static void main(String[] args) {
		SpringApplication.run(Que4Application.class, args);
	}

}
