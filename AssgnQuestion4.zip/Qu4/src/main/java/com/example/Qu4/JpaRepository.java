package com.example.Qu4;

public interface JpaRepository<T1, T2> {

}
