package com.example.Que5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProjectService {
    private final ProjectRepository projectRepository;

    @Autowired
    public ProjectService(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    public Optional<Project> getProjectById(Long projectId) {
        return projectRepository.findById(projectId);
    }

    public Project createProject(Project project) {
        return projectRepository.save(project);
    }

    public Project updateProject(Long projectId, Project newProject) {
        Optional<Project> existingProject = projectRepository.findById(projectId);
        if (existingProject.isPresent()) {
            Project project = existingProject.get();
            project.setProjectName(newProject.getProjectName());
            project.setDateOfStart(newProject.getDateOfStart());
            project.setTeamSize(newProject.getTeamSize());
            return projectRepository.save(project);
        }
        return null;
    }

    public void deleteProject(Long projectId) {
        projectRepository.deleteById(projectId);
    }
}

